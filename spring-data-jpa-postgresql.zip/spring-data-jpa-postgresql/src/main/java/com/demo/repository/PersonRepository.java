package com.demo.repository;

import com.demo.model.Book;
import com.demo.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

// Spring Data JPA creates CRUD implementation at runtime automatically.
public interface PersonRepository extends JpaRepository<Person, Long> {

    List<Book> findByTitle(String title);

    // Custom query
    @Query("SELECT p FROM Person p WHERE p.birtDate > :date")
    List<Book> findByPublishedDateAfter(@Param("date") LocalDate date);

}
